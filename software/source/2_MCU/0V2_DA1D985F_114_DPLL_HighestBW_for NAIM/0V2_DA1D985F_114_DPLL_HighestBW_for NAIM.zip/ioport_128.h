/////////////////////////////////////////////////
//
//	 Title		: ioport.c
//	 Designer	: Seung-Myung Yang
//	 Date		: 2004.06.14
//	 Copyright	: PULSUS Technology.
//	 Revision	: 
//	 	2004.06.14
//	 		First coded.
//
/////////////////////////////////////////////////
//#define		PPCA		1
//#define		PPCB		2
//#define		PPCC		3
//#define		PPCD		4
//#define		PPCE		5
//#define		PPCF		6
//#define		PPCG		7

//void _outport(unsigned char, char);
//unsigned char _inport(unsigned char);
//char _inbit(unsigned char, unsigned char);
//void _outbit(unsigned char, unsigned char, char);
//void _port_init(unsigned char, unsigned char);
//void _bit_init(unsigned char, unsigned char, char);
